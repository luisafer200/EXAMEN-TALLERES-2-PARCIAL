import { Inject, Injectable } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';

@Injectable()
export class AppService {
  constructor(
    @Inject('MESSAGE_SERVICE') private readonly _mailClient: ClientProxy,
    @InjectRepository(User) private readonly userRepository: Repository<User>,
  ) {}

  async nuevoUsauario(body: { name: string; email: string }) {
    // Inserta el usuario en la base de datos
    const newUser = this.userRepository.create(body);
    const savedUser = await this.userRepository.save(newUser);

    // Emite el evento "new_email" al servicio
    this._mailClient.emit('new_email', savedUser);

    return savedUser;
  }
}
